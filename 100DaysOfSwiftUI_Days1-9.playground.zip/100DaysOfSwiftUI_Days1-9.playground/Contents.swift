import UIKit
import Darwin

///*
//    DAY 1: Strings/Variables/Constants/Integers/Doubles/
// */
//var greeting = "Hello, playground"
//
//var name: String = "Ted"
//name = "Rebecca"
//name = "Keeley"
//
//var playerName = "Roy"
//print("Hi, my name is \(playerName)")
//playerName = "Danny"
//print("Hi, my name is \(playerName)")
//playerName = "Sam"
//print("Hi, my name is \(playerName)")
//
//let managerName = "Michael Scott"
//print(managerName)
//let dogBreed = "Retriever"
//
//
//var meaningOfLife = 42
//
//
//print(greeting)
//print("Hi, my name is \(name)")


//        /*
//            DAY 2:  Booleans/String Interpolation
//         `          LEARNED:    .toggle(), .uppercased(), isMultiple(of: int)
//                    BONUS:      Still remember how to create and utilize functions
//         */
//        let celciusTemp: Double = 100
//        print("\(celciusTemp)°C in fahrenheit is \((celciusTemp*9)/5)°F")
//
//        func tempConversion(temp: Double) -> String {
//            let convertedTemp = temp*9/5
//            return "\(temp)°C in fahrenheit is \(convertedTemp)°F"
//        }
//        tempConversion(temp: 120)
//
//        var day = 2
//        var completionStatus = false
//        completionStatus.toggle()
//        print("Day \(day)/100 of #100DaysOfSwiftUI: Status:\(completionStatus)")

///*
//    DAY 3: COMPLEX DATA TYPES - ARRAYS, DICTIONARIES, SETS, AND ENUMS
//                    "Lots of rules and no mercy"
// */
//
//var beatles = ["John", "Paul", "George", "Ringo"]
//let numbers = [4, 8, 15, 16, 23, 42]
//var temperatures = [25.3, 28.2, 26.4]
//
//print(beatles[0])
//print(numbers[1])
//print(temperatures[2])
//
//beatles.append("Adrian")
//
//beatles.append("Allen")
//beatles.append("Adrian")
//beatles.append("Novall")
//beatles.append("Vivian")
//
////temperatures.append("Chris")
//
//let firstBeatle = beatles[0]
//let firstNumber = numbers[0]
////let notAllowed = firstBeatle + firstNumber
//
//var scores = Array<Int>()
//scores.append(100)
//scores.append(80)
//scores.append(85)
//print(scores[1])
//
////var albums = Array<String>()
////albums.append("Folklore")
////albums.append("Fearless")
////albums.append("Red")
//
//var characters = ["Lana", "Pam", "Ray", "Sterling"]
//print(characters.count)
//
//characters.remove(at: 2)
//print(characters.count)
//
//characters.removeAll()
//print(characters.count)
//
//let bondMovies = ["Casino Royale", "Spectre", "No Time To Die"]
//print(bondMovies.contains("Frozen"))

/*
    DAY 4: COMPLEX DATA TYPES PT2 - Type annotation
                    "Good data structures and bad code works alot better than the other way around"
 */

var name: String = "Roy"
var score: Int = 0
var doubleScore: Double = 0

let playerNAme: String = "Ted"
var luckyNumber: Int = 13
let pi: Double = 3.14
var isAuthenticated: Bool = true

var albums: [String] = ["Red","Fearless"]
var user: [String: String] = ["id": "@jrtrubela"]
var books: Set<String> = Set(["The Bluest Eye", "Foundation", "Girl, Woman, Other"])

var soda: [String] = ["Coke", "Pepsi", "Irn-Bru"]
var teams: [String] = [String]()
var cities: [String] = []
var clues = [String]()

enum UIStyle {
    case light, dark, system    }
enum daysOfWeek {   case Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday     }
var today = daysOfWeek.Monday

var style: UIStyle = UIStyle.light
style = .dark

let userName: String
userName = "@jrtrubela"



 //CHECKPOINT 2: Create an array of string , then write some code that prints the number of items in the array and also the number of unique items in the array
 
 var myArray: [String] = ["I ", "just ","completed ", "my ", "4th ", "day", "of ", "hacking with ", "SwiftUI", "SwiftUI"]
 print(myArray)
 print("Number of items in array: \(myArray.count)")
 print("My array contains \"SwiftUI\": \(myArray.contains("SwiftUI"))")

 var myArraySet:Set = Set(myArray)
 print("Number of unique elements in my set: \(myArraySet.count)")

 print(myArraySet)

 

/*
    DAY 5: To be || !To be
 */
//
//enum Weather{
//    case sun,rain,wind,snow,unknown
//}
//
//let forecast = Weather.sun
//
//switch forecast{                                // switch replaces if/else statements
//case .sun:      print("It should be a nice day.")
//case .rain:     print("Pack an umbrella")
//case .wind:     print("Wear a windbreaker")
//case .snow:     print("clean your car off")
//case .unknown:  print("Our forecast generator is broken");fallthrough
//default:        print("blah")
//}
//
//let place = "metropolis"
//
//switch place {
//case "gotham":          print("You're Batman")
//case "mega-city one":   print("You're Judge Dredd")
//case "wakanda":         print("You're Black Panther")
//default:                print("Who are you?")
//}
//


//SWITCHES WITH INTEGER CASES

//let day = 5
//print("my true love gave to me")
//
//switch day{
//case 5:print("5 golden rings");fallthrough
//case 4:print("4 calling birds");fallthrough
//case 3:print("3 french hens");fallthrough
//case 2:print("2 turtle doves");fallthrough
//default:print("partidge in a pair tree")

//
//var temp: Int  = 80
//switch temp {
//case 79: print("its not hot")
//case 80: print("its nice out")
//case 81: print("its hot")
//default: print("temp gauge is broken")
//}

//// Ternary Conditional Operator
//let isAuthenticated = true
////          What            True         False
//print(isAuthenticated ? "Welcome!" : "Who are you?")


/*
        Day 6: Loops
 */

//for i in 1...12 {
//    print("The \(i) times table:")
//    for j in 1...12 {
//        print("  \(j) x \(i) is \(j * i)")
//    }
//    print(" index i is \(i)")
//}
//
//let names = ["Piper", "Alex", "Suzanne", "Gloria"]
////We could read out an individual name like this:
//print(names[0])
//
////With ranges, we can also print a range of values like this:
//print(names[1...3])
////That carries a small risk, though: if our array didn’t contain at least four items then 1...3 would fail.
//
////Fortunately, we can use a one-sided range to say “give me 1 to the end of the array”, like this:
//print(names[1...])
//
//
//var roll = 0
//
//while roll != 20{
//    roll = Int.random(in: 1...20)
//        print("not enough damage done")
//}
//print("Critical hit")


//var page: Int = 0
//while page <= 5 {
//    page += 1
//    print("I'm reading page \(page).")
//}

/*
 CHECKPOINT 3
 Your goal is to loop from 1 through 100, and for each number:

 If it’s a multiple of 3, print “Fizz”
 If it’s a multiple of 5, print “Buzz”
 If it’s a multiple of 3 and 5, print “FizzBuzz”
 Otherwise, just print the number.
 */

//for num in 1...100{
//    if (num%5==0 && num%3 != 0){
//        print("\(num): buzz")
//    }
//    else if (num%3==0 && num%5 != 0){
//        print("\(num): fizz")
//    }
//    else if (num%3==0 && num%5 == 0 || num.isMultiple(of: 5) && num.isMultiple(of: 3)){
//        print("\(num): fizz buzz")
//    }
//    else {
//        print(num)
//    }
//}

/*
 DAY 7 - Functions, PT.1
 */

//func multiply(num: Int,by: Int) -> Int{
//    let result = num*by
//
//    return result;
//}
//multiply(num: 1, by: 2)
//
//func divide(num: Int, by: Int) -> Int{
//    let result = num/by
//
//    return result;
//}
//
//divide(num: 12, by: 3)
//multiply(num: divide(num: 12, by: 4), by: 2)
//
//
//func rollDice() -> Int {
//    return Int.random(in: 1...6)
//}
//let result = rollDice()
//print(result)

//func sameLetters(s1: String,s2: String)->Bool{
//    s1.sorted() == s2.sorted()                  // since its only one line of code we do not need to return, it knows to return the value
////    return s1.sorted() == s2.sorted()
////
////    for i in s1 {
////        if s2.contains(i){
////            result = true
////            break
////        }
////        else{
////            continue
////        }
////    }
////    return result
//    
//}
//var s1 = "String"
//var s2 = "String"
//sameLetters(s1: s1, s2: s2)
//
//func pythagorus(a: Double, b: Double) -> Double{
//    sqrt((a*a+b*b))
//}
//var a = pythagorus(a: 3, b: 4)
//print(a)
//
//func greet(name: String) -> String {
//    name == "Taylor Swift"
//    ?"oh wow" : "hello \(name)"
//}
//
//print(greet(name: "Taylor Swift"))
//
//
///**********************************************************************************************************************************************************************************/
// 
//                                        func getName() -> (firstName: String, lastName: String){
//                                                          (firstName: "Taylor", lastName: "Swift")            }
///*DESTRUCTURING A TUPLE*/
//                                        let (firstName, lastName) = getName()
//                                        print(firstName, lastName)
//
///**********************************************************************************************************************************************************************************/
//
//
//
//func getUser() -> (firstNameUser: String, lastNameUser: String) {
//    ("User", "2")
//}
//
//let (firstNameUser, lastNameUser) = getUser()
//print(firstNameUser,lastNameUser)
//
//
//var score = (10,"winner")
////score = (10, 10)
//
//print(score.0)
//
//func isUppercase(_: String) -> Bool {
//    string==string.uppercased()
//}
//
//let string = "HELLO, WORLD"
//isUppercase(string)
//
//func printTimesTable(for num: Int) {            //adding an external name(for) for the paramater while still keeping internal parameter call                                                    (num) syntactically logical
//    for i in 1...12 {
//            print("\(i) x \(num) = \(i*num)")
//    }
//}
//
//print
//printTimesTable(for: 6)
//
//
//
//
//
//
//
//
//func multiplyBy(by:Int)->Int{
//    let num = 5
//    return num*by
//}
//multiplyBy(by: 5)
//
//func multiplyBy(_ num: Int)->Int{
//    5*num
//}
//multiplyBy(5)
//


/*
    DAY 8: Functions PT2: Handling errors
 */

// You can default any or all of the paramaters in your function by initializing them to a "default value"

//func timesTable(for number: Int, range: Int = 10){
//    for i in 0...range{
//        print("\(number) * \(i) = \(number * i)")
//    }
//}
////timesTable(for: 5, range: 10)      =       timesTable(for: 5)
//
////swift gives enough memory to hold the array data plus a little extra
//// sometimes you want to remove data but you know that your going to add alot more
//// so to save time we call this to save some "time"
//var array = ["Hello,", "this", "shows", "default", "value", "for", "arrays"]
//array.count
//array.removeAll(keepingCapacity: false)
//array.count
//
///*
//    HANDLING ERRORS IN FUNCTIONS
//    Step1: define all the errors that might happen in the code were writing
//    Step2: write a function that runs as normal but checks for these errors
//    Step3: try and run that function and handle any errors that come back
// */
//
////Define errors
//enum PasswordError: Error {
//    case short, obvious
//}
//
////Check for errors
//func checkPassword(_ password: String) throws -> String {
//    if password.count < 5 {throw PasswordError.short}
//    if password == "12345" {throw PasswordError.obvious}
//
//    if password.count < 8{
//        return "ok"
//    }
//    else if password.count < 10 {
//        return "good"
//    }
//    else {
//        return "excelent"
//    }
//}
//let string = "12345"
//
//do {
//    let result = try checkPassword(string)
//    print("password rating: \(result)")
//}
////catch PasswordError.obvious{
////    print("I have the same password on my luggage!")
////}
////catch PasswordError.short{
////    print("Password must be greater than 5 characters")
////}
//catch{
//    print("There was an error:  \(error.localizedDescription)")
//}
////checkPassword("123456")



/*
 Checkpoint 4
 We’ve covered a lot about functions in the previous chapters, so let’s recap:

 Functions let us reuse code easily by carving off chunks of code and giving it a name.
 All functions start with the word func, followed by the function’s name. The function’s body is contained inside opening and closing braces.
 We can add parameters to make our functions more flexible – list them out one by one separated by commas: the name of the parameter, then a colon, then the type of the parameter.
 You can control how those parameter names are used externally, either by using a custom external parameter name or by using an underscore to disable the external name for that parameter.
 If you think there are certain parameter values you’ll use repeatedly, you can make them have a default value so your function takes less code to write and does the smart thing by default.
 Functions can return a value if you want, but if you want to return multiple pieces of data from a function you should use a tuple. These hold several named elements, but it’s limited in a way a dictionary is not – you list each element specifically, along with its type.
 Functions can throw errors: you create an enum defining the errors you want to happen, throw those errors inside the function as needed, then use do, try, and catch to handle them at the call site.
 */


/*The challenge is this: write a function that accepts an integer from 1 through 10,000, and returns the integer square root of that number. That sounds easy, but there are some catches:
 
 -You can’t use Swift’s built-in sqrt() function or similar – you need to find the square root yourself.

 -If the number is less than 1 or greater than 10,000 you should throw an “out of bounds” error.
 
 -You should only consider integer square roots – don’t worry about the square root of 3 being 1.732, for example.
    If you can’t find the square root, throw a “no root” error.
 */

//Step1: declare a set of valid throw cases
//enum squarerootError: Error { case noRoot, outOfBounds }
//
////Step2: Write the function that will catch the errors
//func squareRoot(of number: Int) throws -> Int{
//    var root = 0
//    if number < 1 || number > 10_000{ throw squarerootError.outOfBounds }      //Catch error: OutOfBounds
//    for i in 1...100{
//        if i*i == number {
//            root = i
//            break
//        }
//        else if root == 0 && i == 100{ throw squarerootError.noRoot }
//    }
//    return root
//}
////Step3: Call the function and handle the errors
//let number = 100
//
//do{    //Try finding the square root for the number given
//    try squareRoot(of: number)
//    print("There is a root for \(number): \(sqrt(Double(number)))")
//}
////Catch all cases for an error
//catch squarerootError.noRoot{
//    print("No root")
//}
//catch squarerootError.outOfBounds{
//    print("out of bounds")
//}
//catch{
//    print("cannot compute")
//}


/*
 DAY 9: CLOSURES
 */

//
//func greetUser() {
//    print("Hi there!")
//}
//
////How to create and use closures
//let sayHello = { (name: String) -> String in
//    "Hi there\(name)!"
//}
//
//sayHello("Justin")
//
//greetUser()
//var greetCopy:() -> Void = greetUser
////var greetCopyFunctionValue = greetCopy()
//
//func getUserData(for id: Int) -> String {
//    if id == 1989 {
//        return "Taylor Swift"
//    }
//    else {
//        return "Anonymous"
//    }
//}
//
//let data: (Int) -> String = getUserData
//let user = data(1989)
//print(user)
//
//
//
//let team = ["Gloria","Suzanne","Piper","Tiffany","Tasha"]
//let sortedTeam = team.sorted()
//print(sortedTeam)
//
////We want suzanne to come first since she is the captain
//
//func captainFirstSorted(name1: String, name2: String) -> Bool {
//    if name1 == "Suzanne"{
//        return true
//    }
//    else if name2 == "Suzanne"{
//        return false
//    }
//        return name1 < name2
//}
//
////let captainFirstTeam = team.sorted(by: captainFirstSorted)
////print(captainFirstTeam)
//
//
//// were condensing both the function call and the sort call into one closure
//
//let captainFirstTeam =  team.sorted(by: { (name1: String, name2: String) -> Bool in
//    if name1 == "Suzanne"{
//        return true
//    }
//    else if name2 == "Suzanne"{
//        return false
//    }
//        return name1 < name2
//})
//print(captainFirstTeam)
//
//let greetUser1 = {
//    print("Hi there!")
//}
//print(greetUser1)
//
//var pickFruit = { (name: String) in
//    switch name {
//    case "strawberry":
//        fallthrough
//    case "raspberry":
//        print("Strawberries and raspberries are half price!")
//    default:
//        print("We don't have those.")
//    }
//}
//
//pickFruit("strawberry")
//
//var cutGrass = { (currentLength: Double) in
//    switch currentLength {
//    case 0.0...1.0:
//        print("That's too short")
//    case 1...3:
//        print("It's already the right length")
//    default:
//        print("That's perfect.")
//    }
//}
//cutGrass(0.5)
//
//
//// How to use trailing colosures and shorthand syntax
////reducing amount of syntax that comes with closures
//
//let reverseTeam = team.sorted { $0 > $1}
//print(reverseTeam)
//
//
////How tto accept functions as paramaters
////thanks to trailing closure syntax
//
//func makeArray(size:Int, using generator: () -> Int) -> [Int] {
//    var numbers = [Int]()
//
//    for _ in 0..<size {
//        let newNumber = generator()
//        numbers.append(newNumber)
//    }
//
//    return numbers
//}
//
//let rolls = makeArray(size: 50) {
//    Int.random(in: 1...20)
//}
//
//func generateNumber() -> Int {
//    Int.random(in: 1...20)
//}
//
//let newRolls = makeArray(size: 50, using: generateNumber)
//print(rolls)
//
//
//func doImportantWork(first: () -> Void, second: () -> Void, third: () -> Void) {
//    print("About to start first work")
//    first()
//    print("About to start second work")
//    second()
//    print("About to start third work")
//    third()
//    print("Done")
//}
//
//doImportantWork {
//    print("this is first work")
//}
//second:{
//        print("this is second work")
//}
//third: {
//    print("this is third work")
//}
//
//let awesomeTalk = {
//    print("Here's a great talk!")
//}
//func deliverTalk(name: String, type: () -> Void) {
//    print("My talk is called \(name)")
//    type()
//}
//deliverTalk(name: "My Awesome Talk", type: awesomeTalk)
//
//
//func goOnVacation(to destination: String, _ activities: () -> Void) {
//    print("Packing bags...")
//    print("Getting on plane to \(destination)...")
//    activities()
//    print("Time to go home!")
//}
//goOnVacation(to: "Mexico") {
//    print("Go sightseeing")
//    print("Relax in sun")
//    print("Go hiking")
//}
//
///*
// You can copy functions in Swift, and they work the same as the original except they lose their external parameter names.
// All functions have types, just like other data types. This includes the parameters they receive along with their return type, which might be Void – also known as “nothing”.
// You can create closures directly by assigning to a constant or variable.
// Closures that accept parameters or return a value must declare this inside their braces, followed by the keyword in.
// Functions are able to accept other functions as parameters. They must declare up front exactly what data those functions must use, and Swift will ensure the rules are followed.
// In this situation, instead of passing a dedicated function you can also pass a closure – you can make one directly. Swift allows both approaches to work.
// When passing a closure as a function parameter, you don’t need to explicitly write out the types inside your closure if Swift can figure it out automatically. The same is true for the return value – if Swift can figure it out, you don’t need to specify it.
// If one or more of a function’s final parameters are functions, you can use trailing closure syntax.
// You can also use shorthand parameter names such as $0 and $1, but I would recommend doing that only under some conditions.
// You can make your own functions that accept functions as parameters, although in practice it’s much more important to know how to use them than how to create them.
// */


/*
 CHECKPOINT 5
 
 With closures under your belt, it’s time to try a little coding challenge using them.

 You’ve already met sorted(), filter(), map(), so I’d like you to put them together in a chain – call one, then the other, then the other back to back without using temporary variables.

 Your input is this:

 let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]
 Your job is to:

 Filter out any numbers that are even
 Sort the array in ascending order
 Map them to strings in the format “7 is a lucky number”
 Print the resulting array, one item per line
 So, your output should be as follows:

 7 is a lucky number
 15 is a lucky number
 21 is a lucky number
 31 is a lucky number
 33 is a lucky number
 49 is a lucky number
 If you need hints they are below, but honestly you should be able to tackle this one either from memory or by referencing recent chapters in this book.
 */


let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]


let luckyOddNumbers = luckyNumbers.filter { number in
    if number % 2 == 0 {
        return false
    }
    else {
        return true
    }
}.sorted {
    $0 < $1
}.map { number in
    return "\(number) is a lucky number"
}
print(luckyOddNumbers)

