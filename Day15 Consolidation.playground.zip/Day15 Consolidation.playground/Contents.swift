import UIKit
import Foundation

let greeting = "Hello, playground"
var greetingCopy = greeting
let myNumber = 5
var myNumberCopy = myNumber
let myBool = false
var myBoolCopy = myBool
let myStringArray = ["string1","string2","string3","string4"]
var myStringArrayCopy = myStringArray
let myIntArray = [1,2,3,4]
var myIntArrayCopy = myIntArray
let myBoolArray = [true,false]
var myBoolArrayCopy = myBoolArray


//learned methods

// String Methods
greetingCopy.hasPrefix("Hello")
greetingCopy.hasSuffix("ground")
greetingCopy.count
greetingCopy.append(contentsOf: "! Welcome")
greetingCopy.uppercased()

//Integer Methods
myNumberCopy.isMultiple(of: 2)

//Boolean Methods
myBoolCopy.toggle()

//Array Methods
myStringArrayCopy.count
myStringArrayCopy.append("string5")
myIntArrayCopy.remove(at: 1)

//Quotes
var quote = "This is a quote written by me: \"I am the only one who can make my dreams happen.\" like that"

//Incrementers
myNumberCopy += 5

//Toggling Booleans
myBoolCopy.toggle()

//sets refresher - can't add duplicates and return no specific order
var numbers = Set([1,1,2,4,7,9])
numbers.insert(10)
//print(numbers)

//enums refresher - list of items that are finite; days of week/months; cases
enum daysOfWeek {
    case Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday
}
enum monthsOfYear {
    case January, February, March, April, May, June, July, August, September, October, November, December
}
let monday = daysOfWeek.Monday
let firstMonth = monthsOfYear.January
var day = daysOfWeek.Monday
//Assigning enum to variable
day = .Friday

//Dictionary refresher
var weekday = [1: "Monday"]
var weekDays = [1: "Monday", 2: "Tuesday"]

print(weekday)
weekday[1]


//Type annotation
var myScore: Double = 0

//Switch refresher
enum Weather {
    case rainy, sunny, snowy, foggy, windy, thunder
}

var forecast = Weather.sunny
switch forecast {
case .rainy: print("It's rainy")
case .sunny: print("It's sunny")
case .snowy: print("It's snowing")
case .foggy: print("It's foggy")
case .windy: print("It's windy")
default: print("Not sure, might be a thunderstorm")
}


//Ternary Conditional operator What: TRUE or FALSE - WTF
var myAge = 17
let myVotingAge = myAge >= 18 ? "Yes" : "No"


//Loop Refresher
let myPlatforms = ["iOS", "TvOS", "iPadOS"]
for os in myPlatforms {
    print(os)
}
for _ in myPlatforms {
    //some code
}
for item in 1...3 {
    print(myIntArray[item])
}


// Throwing errors

enum PasswordError: Error {
    case short, obvious
}

func checkPassword(_ password: String) throws -> String {
    if password.count < 5 {
        throw PasswordError.short
    }

    if password == "12345" {
        throw PasswordError.obvious
    }

    if password.count < 10 {
        return "OK"
    } else {
        return "Good"
    }
}

let myPassword = "12345"

do {
    let result = try checkPassword(myPassword)
    print("Rating: \(result)")
} catch PasswordError.obvious {
    print("I have the same combination on my luggage!")
} catch {
    print("There was an error.")
}


//Closures
let mySayHello = {
    print("Hi there!")
}

mySayHello()


let sayHello = { (name: String) -> String in
    "Hi \(name)!"
}

let team = ["Gloria", "Suzanne", "Tiffany", "Tasha", "Bam","smoke","Justin"]

let onlyT = team.filter({ (name: String) -> Bool in
    return name.hasPrefix("T")
})


//struct <#name#> {
//    <#fields#>
//}


